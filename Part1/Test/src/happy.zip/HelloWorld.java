import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

public class HelloWorld {
    public static void main(String[] args) {
        StdOut.println("Hello " + args[0] +" and " + args[1]);
        StdOut.println("Goodbye " + args[1] + " and " + args[0]);
    }
}